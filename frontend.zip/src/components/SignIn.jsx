import React, { useState } from 'react';
import logoLeft from '../assets/images/logoLeft.png';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const URL = process.env.REACT_APP_URL;

const SignIn = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [formErrors, setFormErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');

  const validateForm = () => {
    const { email, password } = formData;
    let errors = {};
    if (email.trim() === '') {
      errors.email = 'Email is required';
    } else {
      const emailPattern = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
      if (!emailPattern.test(email)) {
        errors.email = 'Invalid email format';
      }
    }
    if (password.trim() === '') {
      errors.password = 'Password is required';
    }
    return errors;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { email, password } = formData;
    if (!email.trim() || !password.trim()) {
      toast.error('Please enter the fields first');
      return;
    }

    const errors = validateForm();
    setFormErrors(errors);
    if (Object.keys(errors).length > 0) return;

    setLoading(true);
    try {
      const response = await axios.post(`${URL}/auth/login`, formData, {
        headers: { 'Content-Type': 'application/json' }
      });

      if (response.status >= 200 && response.status < 300) {
        localStorage.setItem("token", response.data.token);
        localStorage.setItem("role", response.data.role);
        localStorage.setItem("userId", response.data.userId);

        toast.success('Login successfully');
        setTimeout(() => {
          navigate('/cheque-management/dashboard');
        }, 2000);
      } else {
        toast.error("Failed to login");
      }
    } catch (error) {
      console.log("Login error:", error);
      toast.error(error.response?.data?.message || 'User not registered. Please try again!');
    } finally {
      setLoading(false);
    }
  };

  const handleForgetPassword = async (e) => {
    e.preventDefault();
    if (!forgotEmail.trim()) {
      toast.error('Please enter your email.');
      return;
    }
    setLoading(true);
    try {
      const response = await axios.post(`${URL}/auth/forget-password`, { email: forgotEmail });
      if (response.status >= 200 && response.status < 300) {
        toast.success('OTP sent to your email.');
        localStorage.setItem("resetEmail", forgotEmail);
        setTimeout(() => {
          navigate('/cheque-management/forget-password-verification');
        }, 2000);
      } else {
        toast.error('Failed to send OTP.');
      }
    } catch (error) {
      console.error('OTP send error:', error);
      toast.error(error.response?.data?.message || 'Error sending OTP.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="container-fluid sign-page">
        <div className="row sign-main-container">
          <ToastContainer position="top-right" autoClose={3000} hideProgressBar={false} />
          <div className="col-lg-6 sign-left-bg h-100 justify-content-center d-none d-lg-flex align-items-center">
            <img src={logoLeft} alt="logo" />
          </div>

          <div className="col-lg-6 sign-right-bg h-100 bg-EEEEEE position-relative">
            <div className="row h-100 w-100">
              <div className="col-lg-8 col-xl-7 col-xxl-6 mx-auto d-flex justify-content-center align-items-center">
                <div className="w-100">
                  {showForgotPassword ? (
                    <>
                      <h3 className="fw-semibold">Forgot Password</h3>
                      <h6 className="mb-4 text-445B64">Enter your registered email</h6>
                      <input
                        className="form-control mb-3 rounded-3"
                        type="email"
                        value={forgotEmail}
                        onChange={(e) => setForgotEmail(e.target.value)}
                        placeholder="Enter your email"
                      />
                      <button className="btn w-100 sign-btn mb-3" onClick={handleForgetPassword}>
                        {loading ? 'Sending OTP...' : 'Send OTP'}
                      </button>
                      <h6 className="text-center text-445B64">
                        <span
                          className="text-00C7BE text-decoration-none"
                          onClick={() => setShowForgotPassword(false)}
                          style={{ cursor: 'pointer' }}
                        >
                          Back to Sign In
                        </span>
                      </h6>
                    </>
                  ) : (
                    <>
                      <h3 className="fw-semibold">Welcome!</h3>
                      <h6 className="mb-4 text-445B64">Please enter your credentials to log in</h6>
                      <input
                        className="form-control mb-3 rounded-3"
                        type="email"
                        name="email"
                        id="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="Your email address"
                      />
                      {formErrors.email && <small className="text-danger">{formErrors.email}</small>}
                      <input
                        className="form-control mb-1 rounded-3"
                        type="password"
                        name="password"
                        id="password"
                        value={formData.password}
                        onChange={handleChange}
                        placeholder="Your password"
                      />
                      {formErrors.password && <small className="text-danger">{formErrors.password}</small>}
                      <h6 className="text-end text-445B64 mb-3">
                        <span
                          className="text-00C7BE text-decoration-none"
                          onClick={() => setShowForgotPassword(true)}
                          style={{ cursor: 'pointer' }}
                        >
                          Forgot Password?
                        </span>
                      </h6>
                      <button className="btn w-100 sign-btn mb-3" onClick={handleSubmit}>
                        {loading ? (
                          <>
                            <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                            Signing in...
                          </>
                        ) : (
                          "Sign In"
                        )}
                      </button>
                      <h6 className="text-center text-445B64">
                        Don't have an account?
                        <Link to="/cheque-management/sign-up" className="text-00C7BE text-decoration-none"> Sign up</Link>
                      </h6>
                    </>
                  )}
                </div>
              </div>
            </div>
            <div className="position-absolute bottom-0 start-0 w-100">
              <h6 className="text-445B64 text-center">Terms & Conditions • Privacy Policy</h6>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default SignIn;
